'use strict';
const assert = require("assert");
const mongodb = require("mongodb").MongoClient;

const URL = "mongodb://localhost:27017/";

mongodb.connect(URL, { useNewUrlParser: true }, (err, client) => {
    assert.strictEqual(null, err);

    client.db("BeverageVendingMachine").createCollection("light_drinks", (err, collection) => {
        assert.strictEqual(null, err);

        collection.insertMany([
            {
                "name": "Coca-Cola",
                "price": "1.99",
                "quantity": 20
            },
            {
                "name": "Pepsi",
                "price": "1.79",
                "quantity": 20
            },
            {
                "name": "Sprite",
                "price": "1.99",
                "quantity": 20
            },
            {
                "name": "Mountain Dew",
                "price": "2.49",
                "quantity": 20
            }
        ], (err) => {
            assert.strictEqual(null, err);
            client.close();
        });
    });
});

mongodb.connect(URL, { useNewUrlParser: true }, (err, client) => {
    assert.strictEqual(null, err);

    client.db("BeverageVendingMachine").createCollection("hot_drinks", (err, collection) => {
        assert.strictEqual(null, err);

        collection.insertMany([
            {
                "name": "Coffee",
                "price": "0.99",
                "quantity": 20
            },
            {
                "name": "Coffee + Milk",
                "price": "1.49",
                "quantity": 20
            },
            {
                "name": "Green Tea",
                "price": "0.99",
                "quantity": 20
            },
            {
                "name": "White Tea",
                "price": "0.99",
                "quantity": 20
            },
            {
                "name": "Black Tea",
                "price": "1.49",
                "quantity": 20
            }
        ], (err) => {
            assert.strictEqual(null, err);
            client.close();
        });
    });

});

mongodb.connect(URL, { useNewUrlParser: true }, (err, client) => {
    assert.strictEqual(null, err);

    client.db("BeverageVendingMachine").createCollection("machine_stats", (err, collection) => {
        assert.strictEqual(null, err);
        client.close();        
    });

});