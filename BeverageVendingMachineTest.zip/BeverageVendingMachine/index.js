#!/usr/bin/env node
'use strict';
const assert = require("assert");
const inquirer = require("inquirer");
const chalk = require("chalk");
const figlet = require("figlet");
const mongodb = require("mongodb").MongoClient;

const URL = "mongodb://localhost:27017/BeverageVendingMachine";

const drinkTypeQuestion = () => {
    return inquirer.prompt(
        {
            name: "DRINK_TYPE",
            type: "list",
            message: "What kind of drink you wanna buy?",
            choices: [
                {
                    name: "Light beverage",
                    value: "light_drinks"
                },
                {
                    name: "Hot beverage",
                    value: "hot_drinks"
                },
                new inquirer.Separator(),
                {
                    name: "Cancel",
                    value: "cancel"
                }
            ]
        }
    )
}

const selectDrinkQuestion = (drinks) => {
    return inquirer.prompt(
        {
            name: "SELECTED_DRINK",
            type: "list",
            message: "These are the drinks available, choose one:",
            choices: drinks
        }
    );
}

const sugarQuestion = () => {
    return inquirer.prompt(
        {
            type: "confirm",
            name: "SUGAR",
            message: "Do you want sugar with your drink?"
        }
    );
}

const paymentMethodQuestion = (price) => {
    return inquirer.prompt(
        {
            name: "PAYMENT_METHOD",
            type: "list",
            message: `The price for this drink is \$${price} USD. How do you want to pay?`,
            choices: [
                {
                    name: "Coins",
                    value: "coins"
                },
                {
                    name: "Credit Card",
                    value: "credit_card"
                },
                new inquirer.Separator(),
                {
                    name: "Cancel",
                    value: "cancel"
                }
            ]
        }
    );
}

const coinPayment = () => {
    const checkNum = (arg) => /[\d]+/g.test(arg) ? true : "Input must be a number.";

    return inquirer.prompt([
        {
            name: "FIVE_BILL",
            type: "input",
            message: "Number of $5 dollar bills:",
            validate: checkNum
        },
        {
            name: "TWO_BILL",
            type: "input",
            message: "Number of $2 dollar bills:",
            validate: checkNum
        },
        {
            name: "ONE_BILL",
            type: "input",
            message: "Number of $1 dollar bills:",
            validate: checkNum
        },
        {
            name: "FIFTY_CENT",
            type: "input",
            message: "Number of 50c coins:",
            validate: checkNum
        },
        {
            name: "TEN_CENT",
            type: "input",
            message: "Number of 10c coins:",
            validate: checkNum
        },
        {
            name: "PAYMENT_CONTINUE",
            type: "confirm",
            message: "Do you want to continue with payment?"
        }
    ]);
}

const cardPayment = () => {
    return inquirer.prompt([
        {
            name: "CARD_NAME",
            type: "input",
            message: "Name:",
            validate: (input) => {
                if (input.length < 1) {
                    return "Input can\'t be empty."
                }

                return true;
            }
        },
        {
            name: "CARD_NUMBER",
            type: "input",
            message: "Credit Card number:",
            validate: (input) => {
                input = input.replace(/[\-\s]+/g, "");

                if (input.length !== 16) {
                    return "Credit Card number must be 16 digits.";
                }

                if (!(/[\d]+/.test(input))) {
                    return "Credit card number can only have numbers.";
                }

                return true;
            },
            filter: (input) => {
                return input.replace(/[\-\s]+/g, "");
            }
        },
        {
            name: "CARD_EXPIRATION",
            type: "input",
            message: "Expiration date (MM/YYYY):",
            validate: (input) => {
                input.replace(/\s+/g, "");

                if (!(/[\d]{2}[/][\d]{2,4}/.test(input))) {
                    return "Expiration date must be in the format MM/YY or MM/YYYY.";
                }

                return true;
            }
        },
        {
            name: "CARD_CCV",
            type: "input",
            message: "CCV:",
            validate: (input) => {
                input.replace(/\s+/g, "");

                if (!(/[\d]{3}/.test(input))) {
                    return "CCV must be only three digits.";
                }

                return true;
            }
        },
        {
            name: "PAYMENT_CONTINUE",
            type: "confirm",
            message: "Do you want to continue with payment?"
        }
    ]);
}

const getDrinks = (type) => {
    assert.notEqual(null, type);

    return new Promise((resolve, reject) => {
        let selected_drinks = [];
        mongodb.connect(URL, { useNewUrlParser: true }, (err, client) => {
            assert.equal(null, err);
    
            let cursor = client.db().collection(type).find();
    
            cursor.forEach((drink, err) => {
                assert.equal(null, err)
    
                if (drink.quantity > 0) {
                    selected_drinks.push({
                        name: `${drink.name}\t  \t${drink.quantity} available`,
                        value: drink
                    });
                }
            }, () => {
                selected_drinks.push(new inquirer.Separator());
                selected_drinks.push({
                    name: "Cancel",
                    value: "cancel"
                });

                client.close();
                resolve(selected_drinks);
            });
        });
    });
}

const sellDrink = (type, drink) => {
    return new Promise((resolve, reject) => {
        mongodb.connect(URL, { useNewUrlParser: true }, (err, client) => {
            assert.equal(null, err);

            client.db().collection(type).updateOne({_id: drink._id}, {$inc: {quantity: -1}}, () => {
                client.close();
                resolve();
            })
        });
    });
}

const collectStats = (paymentMethod, drink, objCollected) => {
    delete drink.quantity;
    delete drink.name;
    delete drink.price;

    mongodb.connect(URL, { useNewUrlParser: true }, (err, client) => {
        assert.equal(null, err);

        let newStat = {
            drink: drink,
            payment_method: paymentMethod
        }

        if (paymentMethod === "coins") {
            if (objCollected) {
                newStat.cash_amount = objCollected;
            }

            client.db().collection("machine_stats").insertOne(newStat, (err, result) => {
                assert.strictEqual(null, err);
                client.close();
            });
        }
        else if (paymentMethod === "credit_card") {
            client.db().collection("machine_stats").insertOne(newStat, (err, result) => {
                assert.strictEqual(null, err);
                client.close();
            });
        }
    });
}

const exit = async () => {
    let repeat = await inquirer.prompt({
        type: "confirm",
        name: "REPEAT",
        message: "Do you want to buy another drink?"
    });

    if (repeat.REPEAT) {
        return main();
    }
    else {
        console.log( 
            chalk.green(
                figlet.textSync("Goodbye!", {
                    font: "mini"
                })            
            ) 
        );
        return;
    }

}

const main = async () => {
    console.log( chalk.green("Welcome to") );
    console.log(
        chalk.green(
            figlet.textSync("Beverage Vending Machine!", {
                font: "mini"
            })
        )
    );

    let sugarAnswer = null

    // Begin: Selection of drink type
    const drinkTypeAnswer = await drinkTypeQuestion();

    const DRINK_TYPE = drinkTypeAnswer.DRINK_TYPE;

    if (DRINK_TYPE === "cancel"){
        return exit();
    }
    // End: Selection of drink type

    // Begin: Selection of drink
    const drinks = await getDrinks(DRINK_TYPE);
    const selectDrinkAnswer = await selectDrinkQuestion(drinks);
    let SELECTED_DRINK = selectDrinkAnswer.SELECTED_DRINK;
    SELECTED_DRINK.type = DRINK_TYPE;

    if (SELECTED_DRINK === "cancel") {
        return exit();
    }

    if (DRINK_TYPE === "hot_drinks") {
        sugarAnswer = await sugarQuestion();
        SELECTED_DRINK.sugar = sugarAnswer.SUGAR;
    }
    // End: Selection of drink

    // Begin: Selection of payment method
    const paymentAnswer = await paymentMethodQuestion(SELECTED_DRINK.price);

    const PAYMENT_METHOD = paymentAnswer.PAYMENT_METHOD;

    if (PAYMENT_METHOD === "cancel") {
        return exit();
    }
    // End: Selection of payment method
    
    if (PAYMENT_METHOD === "coins") {
    // Begin: Logic for payment with coins
        let coinsInputAmount = 0;
        let coins;
        while (coinsInputAmount < SELECTED_DRINK.price) {
            coins = await coinPayment();

            if (!coins.PAYMENT_CONTINUE) {
                return exit();
            }
    
            coinsInputAmount = (+coins.FIVE_BILL * 5)
                + (+coins.TWO_BILL * 2) 
                + (+coins.ONE_BILL)
                + (+coins.FIFTY_CENT * 0.5) 
                + (+coins.TEN_CENT * 0.1);

            if (coinsInputAmount < SELECTED_DRINK.price) {
                console.log(
                    chalk.red(`The total of coins/bills doesn't add up to ${SELECTED_DRINK.price}. The input coin were discharged, try inputting again.`)
                );
            }
        }

        const changeAmout = coinsInputAmount - SELECTED_DRINK.price;

        const CASH_AMOUNT = {
            input_cash: coinsInputAmount,
            change: +changeAmout.toFixed(2),
            coins: {
                FIVE_BILL: coins.FIVE_BILL,
                TWO_BILL: coins.TWO_BILL,
                ONE_BILL: coins.ONE_BILL,
                FIFTY_CENT: coins.FIFTY_CENT,
                TEN_CENT: coins.TEN_CENT
            }
        }

        await sellDrink(DRINK_TYPE, SELECTED_DRINK);
        await collectStats(PAYMENT_METHOD, SELECTED_DRINK, CASH_AMOUNT);

        console.log(
            chalk.green(`Success! Check in the drop zone for you ${SELECTED_DRINK.name}.`)
        );

        if (changeAmout > 0.0) {
            console.log(
                chalk.yellow(`Don't forget to retrieve your \$${changeAmout.toFixed(2)} change from the machine.`)
            );
        }

    // End: Logic for payment with coins
    } 
    else if (PAYMENT_METHOD === "credit_card") {
    // Begin: Logic for payment with credit card
        
        const {
            CARD_NAME,
            CARD_NUMBER,
            CARD_EXPIRATION,
            CARD_CCV,
            PAYMENT_CONTINUE
        } = await cardPayment();

        if (!PAYMENT_CONTINUE) {
            return exit();
        }

        await sellDrink(DRINK_TYPE, SELECTED_DRINK);

        await collectStats(PAYMENT_METHOD, SELECTED_DRINK, null);

        console.log(
            chalk.green(`Success! Check in the drop zone for you ${SELECTED_DRINK.name}. There is no change.`)
        )

    // End: Logic for payment with credit card
    }
    else {
        return exit();
    }

    exit();
}

main();